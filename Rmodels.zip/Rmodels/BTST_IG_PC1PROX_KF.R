beginTime <- '20110101000000'
endTime <- paste(format(Sys.time(),'%Y%m%d', tz="GMT"),'000000',sep='')
otContext='412'
parameters <- commandArgs(trailingOnly=TRUE)
if(length(parameters)==0){

  saveState = TRUE
  saveHistory = TRUE
  outputModel = TRUE
  baseStateDir <- 'c:/devel/model_rdata'  
  ## one can over ride the end time for testing purpose
  ## other wise the end time defaults to the start of today
  ## GMT
  #endTime <- '20121111000000'  
  outputFile <- stdout()

} else {
# Default values
  saveState = FALSE
  saveHistory = FALSE
  outputModel = TRUE    
  outputFile <- stdout()

}

##### must preserve the name of this variable because the test harness will
##### generate the name of the model base on this variable

modelId <- 'BTST_IG_PC1PROX_KF'
ticker <- 'AXL'

### Load libraries
library(xts)
library(TTR)
library(PerformanceAnalytics)
library(quantmod)
library(dlm)
library(ROneTick)
oneTickLib()

source("../alphaLib/defaults.R")
enableJIT(3)

baseAsciiDir <- 'c:/Devel/model_btst'

# Create directory for model state file
if(saveState==TRUE){
# location of the state file
  stateDir <- paste(baseStateDir,'/BTST_',modelId,sep='')
  if(!file.exists(stateDir))
  {
# creates the target directory if it does not exists
    dir.create(stateDir, recursive=TRUE)
  }
  stateFile <- paste(stateDir,'/',modelId,'.RData',sep='')
}


# Create directory for ascii files
if(saveHistory==TRUE){
# location of the ascii files
  asciiDir <- paste(baseAsciiDir,'/',modelId, sep='')
  if(!file.exists(asciiDir))
  {
    dir.create(asciiDir, recursive=TRUE)
  }    
  asciiLocation <- paste(asciiDir,'/', modelId, sep='')
}


options(scipen=15,digits.secs=6)


#### Get initial CDS values to prime the scrubber #############
init.mid.lead <- 0
init.bo.lead <- 0
init.lead <- oneTickQueryOTQ("../../OneTick/Scrub_Ticks.otq::Get_Sane_Ticks_Priming",
                             start=beginTime,
                             end=endTime,
                             DELAY_TIMESTAMP=30000,
                             OFFER_SCRUB='PAR_SPREAD_OFFER',
                             PRIME_TICKS=30,
                             START_TIME=073000000,
                             BID_SCRUB='PAR_SPREAD_BID',
                             SYMBOLOGY='CMATICKER',
                             CALENDAR='US_FED',
                             END_TIME=170000000,
                             SYMBOL=ticker,
                             SDATE='20130101',
                             TERM=5,
                             MAX=10000,
                             MIN=-10000,
                             DB='CDS_CMA_INTRADAY_E',
                             TZ='America/New_York',
                             running_query=FALSE,
                             apply_times_daily=FALSE,
                             context=otContext)

if(is.null(init.lead)){
  write('Query to retrieive init values failed. Using default.', stdout())
}else{
  init.mid.lead <<- as.numeric(first(init.lead$MID))
  init.bo.lead <<- as.numeric(first(init.lead$BO))
  write(paste('Priming MID value', init.mid.lead, sep=' '), stdout())
  write(paste('Priming BO value', init.bo.lead, sep=' '), stdout())
}

#### Get initial values to prime the scrubber #############
###########################################################################################################
############ lets try to keep the name of the model variable as model.test for all
############ future implementations, so that we don't have to change so much
model.test <- alphaModel(paste("BACEQCDS Model"))
coin <- 2483886.21
vega <- 190000

pnl.factor=1 ##

OTQUERY<-"../../OneTick/Join_Agg_Ticks.otq::Join_Cds_Eq"
timeseries <- oneTickQueryOTQ(OTQUERY,
                              start=beginTime, 
                              end=endTime,
                              DELAY_TIMESTAMP=30000,
                              OFFER_SCRUB_LEAD='PAR_SPREAD_OFFER',
                              BID_SCRUB_LEAD='PAR_SPREAD_BID',
                              SYMBOLOGY_LEAD='CMATICKER',                                                                            
                              INIT_MID_LEAD=init.mid.lead,
                              INIT_BO_LEAD=init.bo.lead,
                              SYMBOL_LEAD=ticker,                              
                              DB_LEAD='CDS_CMA_INTRADAY_E',                        
                              START_TIME=073000000,
                              END_TIME=170000000,
                              MAX_LEAD=10000,
                              MIN_LEAD=-10000,                              
                              MKT_START=093000000,
                              MKT_END=160000000,
                              SYMBOL_EQ=ticker,
                              CALENDAR='US_FED',
                              TZ='America/New_York',
                              DB_EQ='REUTERS_A',
                              running_query=FALSE,
                              SDATE=20130101,
                              apply_times_daily=FALSE,
                              context=otContext)


dv01<-(1-exp(-timeseries$AXL.MID*5e-4) )/(timeseries$AXL.MID*1e-7)
pMid <- timeseries$AXL.MID * dv01 
rMid <- timeseries$EQ.MID
tsPrice <- pMid - (-vega* rMid + coin) #this is the coint (value/value regression) adf stat 7

filtWindow <- 90 #used this to play around with normalization
func.signal <- list(signal.func="signals.alphaModel",
                    filter.func="Filt.RobF.Signal.Multi",
                    filter.params=c(15,5,10,2000), #window,wshift,# of filters, lbound
                    normalize.returns=FALSE,
                    normalize.returns.window= filtWindow,
                    normalize.signal=FALSE,
                    normalize.signal.window= filtWindow,
                    filter.returns=FALSE)

model.test <- alphaModel(paste("AXLEQCDS Model"))

model.test$coin <- coin
model.test$vega <- vega

trading.rules <- list(rules.func="fillOrders.alphaModel", rules.params=rbind(  
  c(-5000,1, 1),  
  c(-9500,1, 1),  
  c(-15000,1,1),
  c(-20000,1,1),
  c(5000,-1, -1),
  c(35000,-1,-1),
  c(15000,-1,-1),
  c(7000,-1, -1)))

model.test <- update.alphaModel(model=model.test,
                                func.signal=func.signal,
                                trading.rules=trading.rules,
                                ts.prices=tsPrice)

system.time(model.test <- recalc.alphaModel(model.test))
plot.alphaModel(model.test, n.flips.max=500)

if(saveState == TRUE){
  ############ Save the RData file for CEP implementation
  plot.alphaModel(model.test, n.flips.max=500)
  system.time(save(model.test, file=stateFile))
}

##### output for t
if(outputModel==TRUE){
  
  lastDay <- format(last(index(tail(model.test))),'%Y-%m-%d')
  
  signals <- model.test$signals[lastDay]      
  position <- model.test$positions[lastDay]
  pnls <- model.test$pnls[lastDay] * pnl.factor
  tickTime <- xts(as.numeric(index(pnls))*1000,order.by=index(pnls))  
  
  oput <- data.frame(    
    cbind('$$',      
          coredata(tickTime),            
          coredata(signals),    
          coredata(position),
          coredata(pnls)      
    )
  )
  
  colnames(oput) <- c('Type',
                      'TickTime' ,        
                      'Signal',    
                      'Position',
                      'PnL')
  
  write.table(oput,row.names=FALSE,file=outputFile, sep=',',quote=FALSE)
}

if(saveHistory){
  ############# Create ascii files for loading ########################
  ############# Save ascii file for historical model loading ##########
  
  ep <- endpoints(model.test$pnls,'days')
  
  for(i in 2:length(ep)){  #length(ep)
    
    start <- index(model.test$pnls[ep[i-1]+1,])
    end <- index(model.test$pnls[ep[i],])
    dFormat <- format(end,format='%Y%m%d')
    fName <- paste(asciiLocation,'.', dFormat,'.data',sep='')
    print(fName)
    
    idx <- paste(format(end,format='%Y-%m-%d'))
    
    pnl <- model.test$pnls[idx] * pnl.factor
    symbol <- xts(rep(modelId,nrow(pnl)),order.by=index(pnl))
    tickType <-xts( rep('MDL',nrow(pnl)),order.by=index(pnl))
    
    tickTime <- xts(as.numeric(index(pnl))*1000,order.by=index(pnl))
    beginTickTime <- xts(as.numeric(index(pnl))*1000,order.by=index(pnl))
    betas <- model.test$betas[idx]
    signals <- model.test$signals[idx]
    bidOffer <- model.test$bidoffers[idx]
    gsCdsBid <- timeseries[idx]$AXL.PAR_SPREAD_BID
    gsCdsOffer <- timeseries[idx]$AXL.PAR_SPREAD_OFFER
    gsBid <- timeseries[idx]$EQ.MID-timeseries[idx]$EQ.BID_OFFER
    gsOffer <- timeseries[idx]$EQ.MID+timeseries[idx]$EQ.BID_OFFER
    position <- model.test$positions[idx]
    prices <- model.test$prices[idx]
    
    oput <- data.frame(
      
      cbind(
        coredata(symbol),
        coredata(tickTime),
        coredata(beginTickTime),
        coredata(betas),
        coredata(signals),
        coredata(gsCdsBid),
        coredata(gsCdsOffer),
        coredata(gsBid),
        coredata(gsOffer),      
        coredata(position),
        coredata(prices),
        coredata(bidOffer),
        coredata(pnl),
        coredata(tickType)
      )
    )
    
    type <- data.frame(
      cbind('string[64]',
            'msectime timezone=GMT',
            'msectime timezone=GMT',
            'double',
            'double',
            'double',
            'double',
            'double',
            'double',
            'double',
            'double',
            'double',
            'double',
            'MDL')
    ) 
    
    colnames(oput) <- c( 
      'Symbol',
      'TickTime' ,
      'BeginTimeStamp',
      'Betas',
      'Signal',
      'AXLCDSBid',
      'AXLCDSOffer',
      'AXLBid',
      'AXLOffer',
      'Position',
      'PriceLevel',
      'BidOffer',
      'Pnl',
      'TICK_TYPE')   
    
    colnames(type) <- colnames(oput)
    oput <- rbind(type,oput)
    
    write.table(oput,row.names=FALSE,file =fName, sep=',',quote=FALSE)
    
  }
}
